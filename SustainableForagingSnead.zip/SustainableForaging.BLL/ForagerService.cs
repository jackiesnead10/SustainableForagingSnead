﻿using SustainableForaging.Core.Models;
using SustainableForaging.Core.Repositories;
using System.Collections.Generic;
using System.Linq;

namespace SustainableForaging.BLL
{
    public class ForagerService
    {
        private readonly IForagerRepository repository;

        public ForagerService(IForagerRepository repository)
        {
            this.repository = repository;
        }

        public List<Forager> FindByState(string stateAbbr)
        {
            return repository.FindByState(stateAbbr);
        }
        // add a function where you can add lower case/upper case to this method
        public List<Forager> FindByLastName(string prefix)
        {
            return repository.FindAll()
                    .Where(i => i.LastName.ToLower().StartsWith(prefix.ToLower()))
                    .ToList();
        }
   
    public Result<Forager> Add(Forager forager)
        {
            List<Forager> lastnameList = FindByLastName(forager.LastName[0].ToString());

            foreach(Forager s in lastnameList)
            {
                if (s.LastName.Equals(forager.LastName))
                {
                    if (s.FirstName.Equals(forager.FirstName))
                    {
                        if (s.State.Equals(forager.State))
                        {
                            Result<Forager> result = new Result<Forager>();
                            result.AddMessage("[ERROR]Duplicate entry, try again:");
                            return result;

                        }
                    }
                }
            }
            Result<Forager> success = new Result<Forager>();
            success.Value = forager;
            repository.Add(forager);
            return success;



        }

    }
}
