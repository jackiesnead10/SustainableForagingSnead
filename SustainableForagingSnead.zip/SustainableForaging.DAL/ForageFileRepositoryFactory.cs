﻿using SustainableForaging.Core.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SustainableForaging.DAL
{
    public class ForageFileRepositoryFactory
    {
        public static IForageRepository GetForageRespository(string directory)
        {
            IForageFileRepository foragerepo = new IForageFileRepository(directory);
            return foragerepo;
        }
    }
}
