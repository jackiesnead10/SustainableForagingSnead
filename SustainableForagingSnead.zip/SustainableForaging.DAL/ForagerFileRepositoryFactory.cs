﻿using SustainableForaging.Core.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SustainableForaging.DAL
{
    public class ForagerFileRepositoryFactory
    {
        public static IForagerRepository GetForagerRespository(string directory)
        {
            ForagerFileRepository foragerrepo = new ForagerFileRepository(directory);
            return foragerrepo;
        }
    }
}
