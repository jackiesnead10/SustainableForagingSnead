﻿using SustainableForaging.Core.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SustainableForaging.DAL
{
    public class ItemFileRespositoryFactory
    {
        public static IItemRepository GetItemRespository(string directory)
        {
            ItemFileRepository itemrepo = new ItemFileRepository(directory);
            return itemrepo;
        }
    }
}
