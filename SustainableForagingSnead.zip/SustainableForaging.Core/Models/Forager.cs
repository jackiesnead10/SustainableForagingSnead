﻿namespace SustainableForaging.Core.Models
{
    public class Forager
    {
        public string Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string State { get; set; }
    }
}
