﻿using NUnit.Framework;
using SustainableForaging.BLL.Tests.TestDoubles;
using SustainableForaging.Core.Models;
using System;
using System.Collections.Generic;

namespace SustainableForaging.BLL.Tests
{
    public class ForageServiceTest
    {
        ForageService service = new ForageService(
           new ForageRepositoryDouble(),
           new ForagerRepositoryDouble(),
           new ItemRepositoryDouble());

        [Test]
        public void ShouldAdd()
        {
            Forage forage = new Forage();
            forage.Date = DateTime.Today;
            forage.Forager = ForagerRepositoryDouble.FORAGER;
            forage.Item = ItemRepositoryDouble.ITEM;
            forage.Kilograms = 0.5M;

            Result<Forage> result = service.Add(forage);
            Assert.IsTrue(result.Success);
            Assert.NotNull(result.Value);
            Assert.AreEqual(36, result.Value.Id.Length);
        }

        [Test]
        public void ShouldNotAddWhenForagerNotFound()
        {
            Forager forager = new Forager();
            forager.Id = "30816379-188d-4552-913f-9a48405e8c08";
            forager.FirstName = "Ermengarde";
            forager.LastName ="Sansom";
            forager.State ="NM";

            Forage forage = new Forage();
            forage.Date = DateTime.Today;
            forage.Forager = forager;
            forage.Item = ItemRepositoryDouble.ITEM;
            forage.Kilograms = 0.5M;

            Result<Forage> result = service.Add(forage);
            Assert.IsFalse(result.Success);
        }

        [Test]
        public void ShouldNotAddWhenItemNotFound()
        {
            Item item = new Item(11, "Dandelion", Category.Edible, 0.05M);

            Forage forage = new Forage();
            forage.Date = DateTime.Today;
            forage.Forager = ForagerRepositoryDouble.FORAGER;
            forage.Item = item;
            forage.Kilograms =0.5M;

            Result<Forage> result = service.Add(forage);
            Assert.IsFalse(result.Success);
        }
        [Test]
        public void ShouldNotGetFakeDate()
        {
            DateTime fakedate = new DateTime();
            DateTime.TryParse("05/05/2020", out fakedate);
            Dictionary<string, decimal> kiloreport = service.GetKiloReport(fakedate.Date);

            Assert.IsEmpty(kiloreport);
        }
        [Test]
        public void ShouldGetRealdate()
        {
            DateTime realdate = new DateTime();
            DateTime.TryParse("06/26/2020", out realdate);
            Dictionary<string, decimal> kiloreport = service.GetKiloReport(realdate.Date);
           
            Assert.IsNotEmpty(kiloreport);
        }
        [Test]
        public void ShouldNotGetFakeValueDate()
        {
            DateTime fakedate = new DateTime();
            DateTime.TryParse("05/05/2020", out fakedate);
            Dictionary<Category, decimal> valuereport = service.GetTotalValueReport(fakedate.Date);

            Assert.IsEmpty(valuereport);
        }
        [Test]
        public void ShouldGetRealValuedate()
        {
            DateTime realdate = new DateTime();
            DateTime.TryParse("06/26/2020", out realdate);
            Dictionary<Category, decimal> valuereport = service.GetTotalValueReport(realdate.Date);

            Assert.IsNotEmpty(valuereport);
        }
        [Test]
        public void ShouldNotAddDuplicateForage()
        {
            DateTime date = new DateTime();
            Forage forage = new Forage();

            forage.Id = "498604db-b6d6-4599-a503-3d8190fda823";
            DateTime.TryParse("06/26/2020", out date);
            forage.Date = date;
            forage.Forager = ForagerRepositoryDouble.FORAGER;
            forage.Item = ItemRepositoryDouble.ITEM;
            forage.Kilograms = 1.25M;
            

            Result<Forage> result = service.Add(forage);

            Assert.IsFalse(result.Success);
        }



    }
}
