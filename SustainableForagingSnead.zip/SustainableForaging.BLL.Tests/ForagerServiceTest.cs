﻿using NUnit.Framework;
using SustainableForaging.BLL.Tests.TestDoubles;
using SustainableForaging.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SustainableForaging.BLL.Tests
{
    class ForagerServiceTest
    {
        ForagerService forservice = new ForagerService(new ForagerRepositoryDouble());

        [Test]
        public void ShouldAddForager()
        {
            Forager forager = new Forager();
            forager.Id = Guid.NewGuid().ToString();
            forager.FirstName = "Terry";
            forager.LastName = "Merry";
            forager.LastName = "Alaska";
            Result<Forager> result = forservice.Add(forager);


            Assert.IsTrue(result.Success);


        }

        [Test]
        public void ShouldNotAddDuplicate()
        {
            Forager forager = new Forager();
            forager.Id = "0e4707f4-407e-4ec9-9665-baca0aabe88c";
            forager.FirstName = "Jilly";
            forager.LastName = "Sisse";
            forager.State = "GA";
            Result<Forager> result = forservice.Add(forager);

            Assert.IsFalse(result.Success);



        }


    }
}
