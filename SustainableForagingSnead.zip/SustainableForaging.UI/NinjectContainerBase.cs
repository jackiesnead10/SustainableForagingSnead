﻿using Ninject;
using SustainableForaging.BLL;
using SustainableForaging.DAL;
using System;
using System.IO;
using SustainableForaging.Core.Repositories;

namespace SustainableForaging.UI

{
    public static class NinjectContainerBase
    {

        public static StandardKernel Kernal { get; private set; }

        public static void Configure()
        {
            string projectDirectory = Directory.GetParent(Environment.CurrentDirectory).Parent.Parent.FullName;
            string forageFileDirectory = Path.Combine(projectDirectory, "data", "forage_data");
            string foragerFilePath = Path.Combine(projectDirectory, "data", "foragers.csv");
            string itemFilePath = Path.Combine(projectDirectory, "data", "items.txt");
            Kernal = new StandardKernel();
            Kernal.Bind<IForageRepository>().To<IForageFileRepository>().WithConstructorArgument("directory", forageFileDirectory);
            Kernal.Bind<IForagerRepository>().To<ForagerFileRepository>().WithConstructorArgument("filePath", foragerFilePath);
            Kernal.Bind<IItemRepository>().To<ItemFileRepository>().WithConstructorArgument("filePath", itemFilePath);
           
            

        }


    }
}