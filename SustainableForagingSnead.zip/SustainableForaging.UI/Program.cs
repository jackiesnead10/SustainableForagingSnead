﻿using Ninject;
using SustainableForaging.BLL;
using SustainableForaging.DAL;
using System;
using System.IO;
using SustainableForaging.Core.Repositories;

namespace SustainableForaging.UI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            ConsoleIO io = new ConsoleIO();
            View view = new View(io);
            
            string projectDirectory = Directory.GetParent(Environment.CurrentDirectory).Parent.Parent.FullName;
            string forageFileDirectory = Path.Combine(projectDirectory, "data", "forage_data");
            string foragerFilePath = Path.Combine(projectDirectory, "data", "foragers.csv");
            string itemFilePath = Path.Combine(projectDirectory, "data", "items.txt");

            /*
            StandardKernel Kernal = new StandardKernel();
            Kernal.Bind<IForageRepository>().To<ForageFileRepository>().WithConstructorArgument("directory");
            Kernal.Bind<IForagerRepository>().To<ForagerFileRepository>().WithConstructorArgument("filePath");
            Kernal.Bind<IItemRepository>().To<ItemFileRepository>().WithConstructorArgument("filePath");
            
            NinjectContainerBase.Configure();
            var forageFileRepository = NinjectContainerBase.Kernal.Get<ForageFileRepository>();
            var foragerFileRepository = NinjectContainerBase.Kernal.Get<ForagerFileRepository>();
            var itemFileRepository = NinjectContainerBase.Kernal.Get<ItemFileRepository>();
            */
            IForageRepository forageFileRepository = ForageFileRepositoryFactory.GetForageRespository(forageFileDirectory);
            IForagerRepository foragerFileRepository = ForagerFileRepositoryFactory.GetForagerRespository(foragerFilePath);
            IItemRepository itemFileRepository = ItemFileRespositoryFactory.GetItemRespository(itemFilePath);



            ForagerService foragerService = new ForagerService(foragerFileRepository);
            ForageService forageService = new ForageService(forageFileRepository, foragerFileRepository, itemFileRepository);
            ItemService itemService = new ItemService(itemFileRepository);
            ConsoleIO consoleIO = new ConsoleIO();

            Controller controller = new Controller(foragerService, forageService, itemService, view, consoleIO);
            controller.Run();
        }
       
  
    
    }
}
