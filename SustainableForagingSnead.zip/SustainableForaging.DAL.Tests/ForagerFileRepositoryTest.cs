﻿using NUnit.Framework;
using SustainableForaging.Core.Models;
using System;
using System.Collections.Generic;
using SustainableForaging.Core;
using SustainableForaging.BLL;

namespace SustainableForaging.DAL.Tests
{
    public class ForagerFileRepositoryTest
    {
        [Test]
        public void ShouldFindAll()
        {
            ForagerFileRepository repo = new ForagerFileRepository(@"data\foragers.csv");
            List<Forager> all = repo.FindAll();
            Assert.AreEqual(1001, all.Count);
        }
        [Test]
        public void ShouldAddForager()
        {
            Forager forager = new Forager();
            ForagerFileRepository repo = new ForagerFileRepository(@"data\foragers.csv");

            forager.Id = Guid.NewGuid().ToString();
            forager.FirstName = "Terry";
            forager.LastName = "Merry";
            forager.LastName = "Alaska";

            forager = repo.Add(forager);
           

            Assert.IsNotNull(forager);
            //  Result<Forager> result = repo.Add(forager);

        }

    }
}
